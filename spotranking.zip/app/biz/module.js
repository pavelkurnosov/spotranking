"use strict";


angular.module('app.biz', ['ui.router'])
.config(function ($stateProvider) {
    $stateProvider
        .state('app.biz', {})
        .state('app.biz.mainSearch', {
            url: '/main_search',
            data: {
                title: 'Main Search'
            },
            views: {
                "content@app": {
                    templateUrl: 'app/biz/views/main-search.html',
                    controller: 'MainSearchController'
                }
            }
        })
});
