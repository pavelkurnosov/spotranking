'use strict';

angular.module('app.biz').controller('MediaOutletController', function ($scope) {


});