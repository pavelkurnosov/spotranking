'use strict';

angular.module('app.biz').controller('MediaOutletController', function (DTOptionsBuilder, DTColumnBuilder) {
    var vm = this;
    vm.standardOptions = DTOptionsBuilder
        .fromSource('app/biz/outlet_data.json')
        .withDOM("<'dt-toolbar'<'col-xs-12 col-sm-6'f><'col-sm-6 col-xs-12 hidden-xs'l>r>t<'dt-toolbar-footer'<'col-sm-6 col-xs-12 hidden-xs'i><'col-xs-12 col-sm-6'p>>")
        .withButtons([
            /*'columnsToggle',*/
            'colvis',
            'print',
            'copy',
            'pdf',
            'excel',
            'csv'/*,
            {
                text: 'Some button',
                key: '1',
                action: function (e, dt, node, config) {
                    alert('Button activated');
                }
            }*/
        ])
        .withBootstrap();

    vm.standardColumns = [
        DTColumnBuilder.newColumn('newspapers')/*.withClass('text-danger')*/,
        DTColumnBuilder.newColumn('country'),
        DTColumnBuilder.newColumn('lang'),
        DTColumnBuilder.newColumn('ymd'),
        DTColumnBuilder.newColumn('circulation'),
        DTColumnBuilder.newColumn('np_subject'),
        DTColumnBuilder.newColumn('ads_no'),
        DTColumnBuilder.newColumn('ad_np_section'),
        DTColumnBuilder.newColumn('ad_location')
    ];
});