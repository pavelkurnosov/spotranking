'use strict';

angular.module('app.biz').controller('RtvReportController', function ($scope) {


});