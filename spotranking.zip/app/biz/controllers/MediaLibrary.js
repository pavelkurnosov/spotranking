'use strict';

angular.module('app.biz').controller('MediaLibraryController', function ($scope) {


});