'use strict';

angular.module('app.biz').controller('MainSearchController', function ($scope) {


});