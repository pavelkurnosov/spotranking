'use strict';

angular.module('app.home').controller('HomeController', function ($scope) {


});